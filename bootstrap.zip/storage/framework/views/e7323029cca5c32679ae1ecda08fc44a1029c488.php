<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('favicon.ico')); ?>" rel="shortcut icon">
    <title>SIRADIG - Politeknik Statistika STIS</title>
</head>

<body>
    <div id="app">
        <router-view :user="<?php echo e(Auth::user()); ?>"></router-view>
    </div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\forum_diskusi\resources\views/materi.blade.php ENDPATH**/ ?>