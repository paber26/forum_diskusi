<template>
    <div class="bg-blue-200 p-2 font-semibold">Politeknik Statistika STIS</div>
</template>